ALTER TABLE "#__privacy_consents" ADD "state" "smallint" NOT NULL DEFAULT 1;
