ALTER TABLE `#__privacy_requests` DROP INDEX `idx_checkout`;
ALTER TABLE `#__privacy_requests` DROP COLUMN `checked_out`;
ALTER TABLE `#__privacy_requests` DROP COLUMN `checked_out_time`;
