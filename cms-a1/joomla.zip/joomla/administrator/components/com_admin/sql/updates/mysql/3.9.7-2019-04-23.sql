ALTER TABLE `#__session` ADD INDEX `client_id_guest` (`client_id`, `guest`);
