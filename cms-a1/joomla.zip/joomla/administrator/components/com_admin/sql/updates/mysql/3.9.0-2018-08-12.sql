ALTER TABLE `#__privacy_consents` ADD COLUMN `state` INT(10) NOT NULL DEFAULT 1 AFTER `user_id`;
