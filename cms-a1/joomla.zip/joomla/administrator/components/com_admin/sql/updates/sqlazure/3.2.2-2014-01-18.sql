/* Update updates version length */
ALTER TABLE [#__updates] ALTER COLUMN [version] [nvarchar](32);
